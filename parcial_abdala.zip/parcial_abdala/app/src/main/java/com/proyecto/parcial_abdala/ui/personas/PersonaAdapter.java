package com.proyecto.parcial_abdala.ui.personas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.proyecto.parcial_abdala.R;
import com.proyecto.parcial_abdala.modelo.Persona;

import java.util.ArrayList;

public class PersonaAdapter extends RecyclerView.Adapter<PersonaAdapter.PersonaViewHolder> {
    private ArrayList<Persona> personas;

    public PersonaAdapter(ArrayList<Persona> personas) {
        this.personas = personas;
    }

    @NonNull
    @Override
    public PersonaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_persona, parent, false);
        return new PersonaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PersonaViewHolder holder, int position) {
        Persona persona = personas.get(position);
        holder.bind(persona);
    }

    @Override
    public int getItemCount() {
        return personas.size();
    }

    static class PersonaViewHolder extends RecyclerView.ViewHolder {
        private TextView txtNombre, txtApellido, txtDni, txtEdad;

        public PersonaViewHolder(@NonNull View itemView) {
            super(itemView);
            txtNombre = itemView.findViewById(R.id.txtNombre);
            txtApellido = itemView.findViewById(R.id.txtApellido);
            txtDni = itemView.findViewById(R.id.txtDni);
            txtEdad = itemView.findViewById(R.id.txtEdad);
        }

        public void bind(Persona persona) {
            txtNombre.setText(persona.getNombre());
            txtApellido.setText(persona.getApellido());
            txtDni.setText(persona.getDni());
            txtEdad.setText(String.valueOf(persona.getEdad()));
        }
    }
}
