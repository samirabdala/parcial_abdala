package com.proyecto.parcial_abdala.ui.personas;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.proyecto.parcial_abdala.modelo.Persona;
import java.util.ArrayList;
import java.util.Collections;

public class PersonaViewModel extends AndroidViewModel {
    private final ArrayList<Persona> personas = new ArrayList<>();
    private MutableLiveData<ArrayList<Persona>> personasLiveData;

    public PersonaViewModel(@NonNull Application application) {
        super(application);
    }


    public LiveData<ArrayList<Persona>> getPersonas() {

        if (personasLiveData == null){
            personasLiveData= new MutableLiveData<>();
        }
        return personasLiveData;
    }

    public void addPersona(Persona persona) {
        personas.add(persona);
        Collections.sort(personas, (p1, p2) -> Integer.compare(p2.getEdad(), p1.getEdad()));
        personasLiveData.setValue(personas);
    }

    public boolean isDniUnique(String dni) {
        for (Persona p : personas) {
            if (p.getDni().equals(dni)) {
                return false;
            }
        }
        return true;
    }
}
