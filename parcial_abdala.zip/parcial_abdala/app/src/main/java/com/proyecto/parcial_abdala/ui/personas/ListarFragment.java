package com.proyecto.parcial_abdala.ui.personas;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.proyecto.parcial_abdala.MainActivity;
import com.proyecto.parcial_abdala.R;
import com.proyecto.parcial_abdala.databinding.FragmentListarBinding;
import com.proyecto.parcial_abdala.modelo.Persona;
import com.proyecto.parcial_abdala.ui.personas.PersonaAdapter;
import com.proyecto.parcial_abdala.ui.personas.PersonaViewModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ListarFragment extends Fragment {

    private FragmentListarBinding binding;
    private PersonaAdapter personaAdapter;
    public static ListarFragment newInstance() {
        return new ListarFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentListarBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        personaAdapter = new PersonaAdapter(MainActivity.personas);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recyclerView.setAdapter(personaAdapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        personaAdapter.notifyDataSetChanged();
    }
}
