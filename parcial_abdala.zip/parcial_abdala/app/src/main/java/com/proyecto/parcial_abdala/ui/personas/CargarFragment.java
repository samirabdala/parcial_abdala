package com.proyecto.parcial_abdala.ui.personas;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.proyecto.parcial_abdala.MainActivity;
import com.proyecto.parcial_abdala.R;
import com.proyecto.parcial_abdala.databinding.FragmentCargarBinding;
import com.proyecto.parcial_abdala.modelo.Persona;
import com.proyecto.parcial_abdala.ui.personas.PersonaViewModel;

public class CargarFragment extends Fragment {
    private FragmentCargarBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentCargarBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.btnGuardar.setOnClickListener(v -> guardarPersona());
    }

    private void guardarPersona() {
        String dni  = binding.etDni.getText().toString().trim();
        String nombre = binding.etNombre.getText().toString().trim();
        String apellido = binding.etApellido.getText().toString().trim();
        String edadStr = binding.etEdad.getText().toString().trim();

        if (nombre.isEmpty() || apellido.isEmpty() || edadStr.isEmpty()) {
            Toast.makeText(getContext(), "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        int edad = Integer.parseInt(edadStr);


        MainActivity.personas.add(new Persona(dni, nombre, apellido, edad));
        Toast.makeText(getContext(), "Persona agregada", Toast.LENGTH_SHORT).show();

        binding.etNombre.setText("");
        binding.etApellido.setText("");
        binding.etEdad.setText("");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
