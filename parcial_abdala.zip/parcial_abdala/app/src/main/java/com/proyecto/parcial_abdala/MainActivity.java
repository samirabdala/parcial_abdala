package com.proyecto.parcial_abdala;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.proyecto.parcial_abdala.databinding.ActivityMainBinding;
import com.proyecto.parcial_abdala.modelo.Persona;
import com.proyecto.parcial_abdala.ui.personas.CargarFragment;
import com.proyecto.parcial_abdala.ui.personas.ListarFragment;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;
    public static ArrayList<Persona> personas = new ArrayList<>();
    private Map<Integer, Fragment> fragmentMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMain.toolbar);

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;

        // Configuración del AppBarConfiguration
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.menu_cargar,
                R.id.menu_listar)
                .setOpenableLayout(drawer)
                .build();

        // Inicializar el mapa de fragmentos
        fragmentMap = new HashMap<>();
        fragmentMap.put(R.id.menu_cargar, new CargarFragment());
        fragmentMap.put(R.id.menu_listar, new ListarFragment());

        // Listener para el botón de salir
        navigationView.setNavigationItemSelectedListener(item -> {
            Fragment selectedFragment = fragmentMap.get(item.getItemId());
            if (selectedFragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.nav_host_fragment_content_main, selectedFragment)
                        .addToBackStack(null)
                        .commit();
            } else if (item.getItemId() == R.id.menu_salir) {
                showExitDialog();
            }
            drawer.closeDrawer(GravityCompat.START);
            return true;
        });
    }

    private void showExitDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Salir")
                .setMessage("¿Deseas salir de la aplicación?")
                .setPositiveButton("Sí", (dialog, which) -> finish())
                .setNegativeButton("No", null)
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        return super.onSupportNavigateUp();
    }
}
