plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.proyecto.parcial_abdala"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.proyecto.parcial_abdala"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation(libs.appcompat) // Biblioteca de compatibilidad
    implementation(libs.material) // Biblioteca de Material Design
    implementation(libs.constraintlayout) // Layout de Constraint
    implementation(libs.lifecycle.livedata.ktx) // LiveData
    implementation(libs.lifecycle.viewmodel.ktx) // ViewModel
    implementation(libs.navigation.fragment) // Navegación para fragmentos
    implementation(libs.navigation.ui) // Navegación UI
    testImplementation(libs.junit) // Pruebas unitarias
    androidTestImplementation(libs.ext.junit) // Pruebas instrumentadas
    androidTestImplementation(libs.espresso.core) // UI testing con Espresso
    implementation(libs.recyclerview)

}
